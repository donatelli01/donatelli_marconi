# README
##### Istruzioni per la configurazione
?
##### Guida all'installazione
?
##### Un elenco dei file contenuti nel pacchetto
File access:
- TxLogistikFrontEnd.accdb (file access contenente tabelle, query, maschere e macro);
- TxLogistikBackEnd.accdb (file access da dove si reperisce le tabelle originali in caso di cambiamento/problemi);
##### Informazioni riguardo al tipo di licenza e il copyright
-- COMING SOON --
##### Contatti del distributore e del programmatore
Distributore:
- Professor Gianni Bellini: gbellini@marconivr.it;

Programmatore:
- Gli alunni della classe 5CI: 
    - Novelli Matteo: matteonovelli.pro@gmail.com;
    - Venturi Alberto: venturi.alberto99@gmail.com;
    - Rossetto Thomas: rossetto.thomas9@gmail.com;
##### Eventuali bug (conosciuti)
Nessun bug riscontrato
##### Risoluzione di problemi
Durante l'incontro con gli esponenti dell'azienda TxLogistik effettuato il dd/mm/yyyy, ci sono stati chiariti i numerosi dubbi e richieste, al fine del corretto utilizzo, delle tabelle e dei record standard che il database deve contenere. Dopo questo meeting abbiamo constatato che il nostro database in access precedetemente sviluppato non soddisfata le richieste del cliente, così abbiamo optato per ricominciarlo da capo.
Poi ci sono stati vari problemi nello sviluppo delle maschere, ma sono stati già risolti. Tabelle e query non hanno alcun problema.
##### Ringraziamenti
Il Developement Team del database per l'azienda cliente TxLogistik ringrazia per l'opportunità datagli e dell'esperienza fornitagli.
##### Un changelog