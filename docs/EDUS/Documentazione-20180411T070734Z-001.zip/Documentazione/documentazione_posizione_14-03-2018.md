# POSIZIONE ATTUALE E FUTURO DEL SERVIZIO

Attualmente abbiamo caricato il nostro servizio web su **altervista**: [edusmarconi](http://edusmarconi.altervista.org).
Sucessivamente verrà inserito all'interno della **DMZ** rendendolo un servizio raggiungibile sia dall'interno che dall'esterno come mostra il **packet tracer** allegato.


